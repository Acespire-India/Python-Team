from django.shortcuts import render

def home(request) :
    return render(request, 'DEMOAPP/index.html')

def products(request) :
    return render(request, 'DEMOAPP/products.html')

def whyweare(request) :
    return render(request, 'DEMOAPP/whyweare.html')

def research(request) :
    return render(request, 'DEMOAPP/research.html')

def about(request) :
    return render(request, 'DEMOAPP/about.html')

def career(request) :
    return render(request, 'DEMOAPP/career.html')

def contact(request) :
    return render(request, 'DEMOAPP/contact.html')

def employee(request) :
    return render(request, 'DEMOAPP/employee.html')